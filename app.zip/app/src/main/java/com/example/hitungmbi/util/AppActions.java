package com.example.hitungmbi.util;

public final class AppActions {
    private AppActions() {}

    public static final String ACTION_BMI_SAVED = "com.example.hitungmbi.ACTION_BMI_SAVED";
}

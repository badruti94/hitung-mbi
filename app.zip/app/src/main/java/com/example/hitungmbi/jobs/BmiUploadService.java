package com.example.hitungmbi.jobs;

import android.content.Context;
import android.content.Intent;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.core.app.JobIntentService;

import com.example.hitungmbi.data.BmiRecord;
import com.example.hitungmbi.data.BmiRepository;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedOutputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

/**
 * Service demo using JobIntentService (safe for Android 8+).
 * This can be triggered from UI for a manual sync.
 */
public class BmiUploadService extends JobIntentService {

    private static final int JOB_ID = 3001;

    public static void enqueue(Context context) {
        enqueueWork(context, BmiUploadService.class, JOB_ID, new Intent(context, BmiUploadService.class));
    }

    @Override
    protected void onHandleWork(@NonNull Intent intent) {
        try {
            BmiRepository repo = new BmiRepository(getApplicationContext());
            List<BmiRecord> batch = repo.getUnsyncedBlocking(25);
            if (batch.isEmpty()) return;

            JSONArray arr = new JSONArray();
            for (BmiRecord r : batch) {
                JSONObject o = new JSONObject();
                o.put("id", r.id);
                o.put("heightCm", r.heightCm);
                o.put("weightKg", r.weightKg);
                o.put("bmi", r.bmi);
                o.put("gender", r.gender);
                o.put("createdAtMillis", r.createdAtMillis);
                arr.put(o);
            }
            JSONObject payload = new JSONObject();
            payload.put("records", arr);

            Log.d("TEST123", "onHandleWork: TESSSSS");

            URL url = new URL("https://hitungmbi-be.vercel.app/api/v1/bmi");
            HttpURLConnection c = (HttpURLConnection) url.openConnection();
            c.setConnectTimeout(10_000);
            c.setReadTimeout(15_000);
            c.setRequestMethod("POST");
            c.setRequestProperty("Content-Type", "application/json");
            c.setDoOutput(true);

            try (OutputStream os = new BufferedOutputStream(c.getOutputStream())) {
                os.write(payload.toString().getBytes());
                os.flush();
            }

            int code = c.getResponseCode();
            if (code >= 200 && code < 300) {
                repo.markSyncedBlocking(batch);
            }
        } catch (Exception ignored) {
        }
    }
}

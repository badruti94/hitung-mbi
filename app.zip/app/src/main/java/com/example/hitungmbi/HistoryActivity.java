package com.example.hitungmbi;

import android.os.Bundle;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.hitungmbi.data.BmiViewModel;

public class HistoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_history);

        RecyclerView rv = findViewById(R.id.recyclerHistory);
        rv.setLayoutManager(new LinearLayoutManager(this));
        HistoryAdapter adapter = new HistoryAdapter();
        rv.setAdapter(adapter);

        BmiViewModel vm = new ViewModelProvider(this).get(BmiViewModel.class);
        vm.observeAll().observe(this, records -> {
            adapter.submit(records);
            if (records == null || records.isEmpty()) {
                Toast.makeText(this, "Belum ada riwayat BMI", Toast.LENGTH_SHORT).show();
            }
        });
    }
}

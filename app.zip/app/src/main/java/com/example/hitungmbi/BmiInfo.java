package com.example.hitungmbi;

public class BmiInfo {
    String category;
    String title;
    String description;
    String detail;

    BmiInfo(String category, String title, String description, String detail) {
        this.category = category;
        this.title = title;
        this.description = description;
        this.detail = detail;
    }
}
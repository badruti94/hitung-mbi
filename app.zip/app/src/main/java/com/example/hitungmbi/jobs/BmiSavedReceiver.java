package com.example.hitungmbi.jobs;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.example.hitungmbi.util.NotificationHelper;

public class BmiSavedReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Log.d("JOB", "BmiSavedReceiver onReceive: " + intent.getAction());
        // 1) Broadcast demo: show a lightweight notification
        NotificationHelper.showSimpleNotification(context, "HitungBMI", "Riwayat BMI tersimpan");

        // 2) Schedule a background sync job (JobScheduler)
        Log.d("JOB", "Calling scheduleOneOffSync()");
        JobSchedulerUtil.scheduleOneOffSync(context);
    }
}
